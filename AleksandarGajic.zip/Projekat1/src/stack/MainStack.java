package stack;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import crtanje.Point;
import crtanje.Rectangle;

import javax.swing.DefaultListModel;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JScrollPane;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class MainStack extends JFrame {

	private JPanel contentPane;
	private DefaultListModel dlm = new DefaultListModel();
	Rectangle r;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainStack frame = new MainStack();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public MainStack() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		JScrollPane scrollPane = new JScrollPane();
		
		JLabel lblStack = new JLabel("Rectangle Stack:");
		
		JButton btnDodaj = new JButton("Dodaj pravougaonik");
		btnDodaj.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DlgRectangle dlgR = new DlgRectangle();
				dlgR.setVisible(true);
				if(dlgR.isOk())
				{
					int x= Integer.parseInt(dlgR.getTxtX().getText());
					int y = Integer.parseInt(dlgR.getTxtY().getText());
					int width = Integer.parseInt(dlgR.getTxtWidth().getText());
					int heigth = Integer.parseInt(dlgR.getTxtHeigth().getText());
					r = new Rectangle(new Point(x,y),width,heigth);
					dlm.add(0,r);
					
				}
			}
		});
		
		JButton btnObrisi = new JButton("Obrisi pravougaonik");
		btnObrisi.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (!dlm.isEmpty())
				{
				DlgRectangle dlgR = new DlgRectangle();
				dlgR.getTxtX().setText(Integer.toString(r.getUpperLeftPoint().getX()));;
				dlgR.getTxtY().setText(Integer.toString(r.getUpperLeftPoint().getY()));
				dlgR.getTxtWidth().setText(Integer.toString(r.getWidth()));
				dlgR.getTxtHeigth().setText(Integer.toString(r.getHeight()));
				dlgR.getTxtX().setEditable(false);
				dlgR.getTxtY().setEditable(false);
				dlgR.getTxtWidth().setEditable(false);
				dlgR.getTxtHeigth().setEditable(false);
				dlgR.setVisible(true);
				if (dlgR.isOk())
				{
					dlm.remove((dlm.size()-1));
					r=null;
				}
				}
				else
				{
					JOptionPane.showMessageDialog(
							contentPane,
							"Lista je prazna!", 
							"Gre�ka", 
							JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.TRAILING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(31)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addComponent(btnDodaj)
						.addComponent(btnObrisi))
					.addPreferredGap(ComponentPlacement.RELATED, 51, Short.MAX_VALUE)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addComponent(lblStack)
						.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 177, GroupLayout.PREFERRED_SIZE))
					.addGap(36))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(23)
					.addComponent(lblStack)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING, false)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addComponent(btnDodaj)
							.addPreferredGap(ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
							.addComponent(btnObrisi))
						.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 118, GroupLayout.PREFERRED_SIZE))
					.addContainerGap(86, Short.MAX_VALUE))
		);
		
		JList list = new JList();
		list.setModel(dlm);
		
		JPanel panel = new JPanel();
		scrollPane.setViewportView(list);
		contentPane.setLayout(gl_contentPane);
		


	}
}
