package sort;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JScrollPane;
import javax.swing.DefaultListModel;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JButton;
import javax.swing.LayoutStyle.ComponentPlacement;
import stack.DlgRectangle;
import crtanje.Rectangle;
import crtanje.Point;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class SortMain extends JFrame {

	private JPanel contentPane;
	private DefaultListModel<Rectangle> dlm = new DefaultListModel<Rectangle>();
	private ArrayList<Rectangle> list = new ArrayList<Rectangle>();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SortMain frame = new SortMain();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public SortMain() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);

		JScrollPane scrollPane = new JScrollPane();

		JButton btnDodaj = new JButton("Dodaj");
		btnDodaj.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DlgRectangle dlgR = new DlgRectangle();
				dlgR.setVisible(true);
				if (dlgR.isOk()) {
					dlm.addElement(new Rectangle(
							new Point(Integer.parseInt(dlgR.getTxtX().getText()),
									Integer.parseInt(dlgR.getTxtY().getText())),
							Integer.parseInt(dlgR.getTxtWidth().getText()),
							Integer.parseInt(dlgR.getTxtHeigth().getText())));
					list.add(new Rectangle(
							new Point(Integer.parseInt(dlgR.getTxtX().getText()),
									Integer.parseInt(dlgR.getTxtY().getText())),
							Integer.parseInt(dlgR.getTxtWidth().getText()),
							Integer.parseInt(dlgR.getTxtHeigth().getText())));
				}
			}
		});

		JButton btnSort = new JButton("Sortiraj");
		btnSort.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (!dlm.isEmpty()) {
					Collections.sort(list, new Comparator<Rectangle>() {
						public int compare(Rectangle r1, Rectangle r2) {
							return r1.compareTo(r2);
						}

					});

					dlm.removeAllElements();
					for (int i = 0; i < list.size(); i++) {
						dlm.addElement(list.get(i));
					}
				} else {
					JOptionPane.showMessageDialog(contentPane, "lista je prazna!", "Gre�ka", JOptionPane.ERROR_MESSAGE);
				}
			}
		});

		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup().addGap(92)
						.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING, false)
								.addGroup(gl_contentPane.createSequentialGroup().addComponent(btnDodaj)
										.addPreferredGap(ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE,
												Short.MAX_VALUE)
										.addComponent(btnSort))
								.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 218, GroupLayout.PREFERRED_SIZE))
						.addContainerGap(114, Short.MAX_VALUE)));
		gl_contentPane
				.setVerticalGroup(
						gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addGroup(gl_contentPane.createSequentialGroup().addGap(35)
										.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 121,
												GroupLayout.PREFERRED_SIZE)
										.addGap(18)
										.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
												.addComponent(btnDodaj).addComponent(btnSort))
										.addContainerGap(55, Short.MAX_VALUE)));

		JList list = new JList();
		list.setModel(dlm);
		scrollPane.setViewportView(list);

		contentPane.setLayout(gl_contentPane);
	}

}
