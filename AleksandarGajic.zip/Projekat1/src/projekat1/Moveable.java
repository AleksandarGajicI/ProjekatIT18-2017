package projekat1;

public interface Moveable {
	public abstract void moveBy(int byX, int byY);
}
